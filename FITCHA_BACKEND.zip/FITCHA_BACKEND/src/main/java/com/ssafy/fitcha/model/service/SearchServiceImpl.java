package com.ssafy.fitcha.model.service;

public class SearchServiceImpl implements SearchService {

}
