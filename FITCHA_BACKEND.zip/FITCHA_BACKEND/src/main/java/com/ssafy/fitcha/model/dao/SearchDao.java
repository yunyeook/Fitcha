package com.ssafy.fitcha.model.dao;

public interface SearchDao {

}
