package com.ssafy.fitcha.config;

public class SecurityConfig {

}
