package com.ssafy.fitcha.config;

public class SwaggerConfig {

}
