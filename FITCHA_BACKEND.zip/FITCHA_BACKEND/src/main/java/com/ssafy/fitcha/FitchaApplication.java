package com.ssafy.fitcha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitchaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitchaApplication.class, args);
	}

}
