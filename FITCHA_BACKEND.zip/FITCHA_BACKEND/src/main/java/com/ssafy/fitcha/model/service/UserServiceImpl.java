package com.ssafy.fitcha.model.service;

public class UserServiceImpl implements UserService {

}
