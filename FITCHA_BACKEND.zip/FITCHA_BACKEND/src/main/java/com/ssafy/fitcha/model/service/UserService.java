package com.ssafy.fitcha.model.service;

public interface UserService {

}
