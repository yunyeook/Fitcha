package com.ssafy.fitcha.controller;

public class CommentController {

}
